@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PY_CMD="
for %%V in (3.13 3.12 3.11 3.10) do (
  if not defined PY_CMD (
    py -%%V -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PY_CMD=py -%%V"
  )
)
if not defined PY_CMD (
  python -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PY_CMD=python"
)
if not defined PY_CMD (
  echo No working Python installation was found.
  pause
  exit /b 1
)
%PY_CMD% -c "import requests, PIL" >nul 2>nul
if errorlevel 1 %PY_CMD% -m pip install -r requirements.txt
%PY_CMD% jav_video_manager.py
if errorlevel 1 pause
