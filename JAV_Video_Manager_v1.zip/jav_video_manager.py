# -*- coding: utf-8 -*-
from __future__ import annotations

import io
import os
import re
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from queue import Queue, Empty
from typing import Optional

import requests
from PIL import Image, ImageTk, ImageDraw
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


APP_TITLE = "JAV Video Manager v0.7.9 - Folder Browser"

VIDEO_EXTS = {
    ".mp4", ".mkv", ".avi", ".wmv", ".mov", ".m4v", ".flv",
    ".ts", ".m2ts", ".webm", ".mpg", ".mpeg"
}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}

# 파일명 파싱 규칙
#
# 화면에 표시할 품번:
#   영문 + 숫자까지만 사용
#
# 단, 파일명 숫자 뒤에 붙은 영문 suffix가 실제 DMM CDN 파일명에 포함되는 사례가 있으므로
# 검색용 보조 후보로만 보관한다.
#
# 예:
#   JKK-500CH.mp4  -> 표시: JKK-500 / DMM 보조 후보: JKK-500CH
#   MKMP426SO.mp4  -> 표시: MKMP-426 / DMM 보조 후보: MKMP-426SO
#
# DMM URL 패턴 생성 알고리즘 자체는 기존 dmm_urls() 그대로 사용한다.
CODE_PATTERN = re.compile(
    r"(?i)(?<![A-Z0-9])([A-Z]{2,20})[-_ .]*(\d{2,8})([A-Z]{0,6})(?![A-Z0-9])"
)


HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/151.0 Safari/537.36"
    ),
    "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    "Referer": "https://www.dmm.co.jp/",
}

REQUEST_TIMEOUT = 10
MIN_IMAGE_BYTES = 5 * 1024
MAX_IMAGE_BYTES = 20 * 1024 * 1024
NETWORK_WORKERS = 6

CARD_W = 250
CARD_H = 310
COVER_W = 220
COVER_H = 165
GAP_X = 12
GAP_Y = 12
OUTER_PAD = 12

VISIBLE_BUFFER_ITEMS = 10
UPDATE_DEBOUNCE_MS = 60

# DMM CDN에서 실제 이미지 key 뒤에 붙는 알려진 suffix.
# 파일명에는 suffix가 없어도 CDN 쪽에는 붙어 있는 케이스가 있음.
# 예: MKMP-426.mp4 -> mkmp426so/mkmp426sopl.jpg
DMM_CODE_SUFFIX_FALLBACKS = ("SO",)


@dataclass
class BrowserItem:
    kind: str  # "folder" / "video"
    name: str
    path: Path
    code: str = ""
    local_image: Optional[Path] = None
    # 화면에 표시하는 품번은 code(영문+숫자)만 사용.
    # 파일명 숫자 뒤에 붙은 영문이 실제 DMM CDN key에 필요한 경우를 위한 검색용 후보.
    # 예: MKMP426SO.mp4 -> code="MKMP-426", dmm_alt_code="MKMP-426SO"
    dmm_alt_code: str = ""


def natural_key(text: str):
    return [
        int(p) if p.isdigit() else p.casefold()
        for p in re.split(r"(\d+)", text)
    ]


def extract_code_info(text: str) -> tuple[str, str]:
    """
    파일명에서 표시용 품번과 DMM 보조 검색 후보를 분리한다.

    표시용 품번은 항상 영문+숫자까지만:
        MKMP426SO.mp4 -> MKMP-426

    숫자 뒤 영문은 화면 품번에는 포함하지 않지만,
    DMM CDN에 실제로 suffix가 포함된 경우를 위해 보조 후보로 보관:
        MKMP426SO.mp4 -> MKMP-426SO

    반환:
        (display_code, dmm_alt_code)

    suffix가 없으면 dmm_alt_code는 빈 문자열.
    """
    stem = Path(text).stem

    cleaned = re.sub(
        r"(?i)\b(?:H26[45]|X26[45]|HEVC|AV1|1080P|2160P|4K|8K|60FPS)\b",
        " ",
        stem
    )

    matches = list(CODE_PATTERN.finditer(cleaned))
    if not matches:
        matches = list(CODE_PATTERN.finditer(stem))

    if not matches:
        return "", ""

    m = matches[-1]

    prefix = m.group(1).upper()
    number = m.group(2)
    suffix = (m.group(3) or "").upper()

    display_code = f"{prefix}-{number}"
    alt_code = f"{prefix}-{number}{suffix}" if suffix else ""

    return display_code, alt_code


def extract_code(text: str) -> str:
    # 기존 호출 호환용
    return extract_code_info(text)[0]


def dmm_key(code: str) -> str:
    return re.sub(r"[^A-Za-z0-9]", "", code).lower()


def dmm_urls(code: str) -> list[str]:
    """
    DMM 이미지 CDN URL 후보를 넓게 생성한다.

    기본 패턴:
    - 1{key}
    - {key}
    - 125{key}

    제조사 prefix 자동 확장:
    - 84{key}
    - 118{key}
    - 55{key}

    h_ 접두사 변형:
    - h_1100{key}r
    - h_1100{key}
    - h_84{key} / h_84{key}r
    - h_084{key} / h_084{key}r
    - h_118{key} / h_118{key}r
    - h_55{key} / h_55{key}r
    - h_055{key} / h_055{key}r
    - h_125{key} / h_125{key}r
    - h_{key} / h_{key}r

    중복 URL은 자동 제거한다.
    """
    key = dmm_key(code)

    urls = []

    def add(path_key: str):
        urls.append(
            f"https://pics.dmm.co.jp/mono/movie/adult/{path_key}/{path_key}pl.jpg"
        )

    # 1) 가장 자주 쓰이는 기본 패턴
    plain_prefixes = [
        "1",
        "",
        "125",
        "84",
        "118",
        "55",
        "41",
    ]
    for prefix in plain_prefixes:
        add(f"{prefix}{key}")

    # 2) h_ 접두사 변형
    h_prefixes = [
        "1100",
        "84",
        "084",
        "118",
        "55",
        "055",
        "125",
        "",
    ]

    for hp in h_prefixes:
        base = f"h_{hp}{key}" if hp else f"h_{key}"
        add(base + "r")
        add(base)

    # 3) 중복 제거 (순서 유지)
    seen = set()
    unique = []
    for u in urls:
        if u not in seen:
            seen.add(u)
            unique.append(u)

    return unique


def choose_local_image(video_path: Path, code: str, images: list[Path]) -> Optional[Path]:
    for p in images:
        if p.stem.casefold() == video_path.stem.casefold():
            return p

    if code:
        compact = re.sub(r"[^a-z0-9]", "", code.casefold())

        for p in images:
            if p.stem.casefold() == code.casefold():
                return p

        for p in images:
            p_compact = re.sub(r"[^a-z0-9]", "", p.stem.casefold())
            if compact and compact in p_compact:
                return p

    return None


def scan_current_directory(folder: Path) -> list[BrowserItem]:
    """
    재귀 탐색하지 않는다.

    현재 폴더에서:
      1. 하위 폴더를 이름순
      2. 현재 폴더에 직접 존재하는 동영상을 이름순
    로 반환한다.
    """
    folders: list[BrowserItem] = []
    videos: list[BrowserItem] = []

    try:
        entries = list(folder.iterdir())
    except OSError as e:
        raise RuntimeError(f"폴더를 읽을 수 없습니다: {folder}\n{e}")

    image_files = [
        p for p in entries
        if p.is_file() and p.suffix.casefold() in IMAGE_EXTS
    ]

    for p in entries:
        if p.is_dir():
            folders.append(
                BrowserItem(
                    kind="folder",
                    name=p.name,
                    path=p
                )
            )

        elif p.is_file() and p.suffix.casefold() in VIDEO_EXTS:
            code, dmm_alt_code = extract_code_info(p.name)

            videos.append(
                BrowserItem(
                    kind="video",
                    name=p.name,
                    path=p,
                    code=code,
                    local_image=choose_local_image(p, code, image_files),
                    dmm_alt_code=dmm_alt_code
                )
            )

    folders.sort(key=lambda x: natural_key(x.name))
    videos.sort(key=lambda x: natural_key(x.name))

    return folders + videos


def contain_image(
    im: Image.Image,
    width: int,
    height: int,
    bg=(245, 245, 245)
) -> Image.Image:
    im = im.convert("RGB")

    if im.width <= 0 or im.height <= 0:
        raise ValueError("invalid image size")

    ratio = min(width / im.width, height / im.height)

    nw = max(1, int(im.width * ratio))
    nh = max(1, int(im.height * ratio))

    resized = im.resize((nw, nh), Image.LANCZOS)

    canvas = Image.new("RGB", (width, height), bg)

    left = (width - nw) // 2
    top = (height - nh) // 2

    canvas.paste(resized, (left, top))

    return canvas


def placeholder_image(label="NO COVER"):
    im = Image.new("RGB", (COVER_W, COVER_H), (235, 235, 235))
    d = ImageDraw.Draw(im)

    d.rectangle(
        (62, 34, 158, 128),
        outline=(145, 145, 145),
        width=3
    )

    d.polygon(
        [(94, 62), (94, 103), (130, 82)],
        fill=(145, 145, 145)
    )

    bbox = d.textbbox((0, 0), label)
    tw = bbox[2] - bbox[0]

    d.text(
        ((COVER_W - tw) / 2, 140),
        label,
        fill=(85, 85, 85)
    )

    return im


def folder_placeholder():
    im = Image.new("RGB", (COVER_W, COVER_H), (245, 245, 245))
    d = ImageDraw.Draw(im)

    # simple folder icon
    d.rounded_rectangle(
        (32, 53, 188, 132),
        radius=8,
        fill=(224, 181, 62),
        outline=(185, 145, 38),
        width=2
    )
    d.rounded_rectangle(
        (47, 37, 111, 68),
        radius=6,
        fill=(231, 193, 80),
        outline=(185, 145, 38),
        width=2
    )

    bbox = d.textbbox((0, 0), "FOLDER")
    tw = bbox[2] - bbox[0]
    d.text(
        ((COVER_W - tw) / 2, 140),
        "FOLDER",
        fill=(90, 90, 90)
    )

    return im


def fetch_dmm_image(code: str, alt_code: str = ""):
    """
    기존 DMM URL 생성 알고리즘(dmm_urls)은 그대로 사용한다.

    1) 표시용 기본 품번으로 먼저 검색
       MKMP-426 -> mkmp426 기반 URL들

    2) 모두 실패하고 파일명에 suffix가 있었다면
       보조 후보로 동일한 URL 패턴을 다시 검색

    3) 파일명에 suffix가 없어도 DMM CDN 쪽에만 SO가 붙는 케이스를 위해
       기본 품번 + SO 후보를 추가로 검색
       MKMP-426 -> MKMP-426SO -> mkmp426so 기반 URL들

    따라서 파일명이 MKMP-426.mp4처럼 suffix가 없어도,
    실제 DMM 이미지가 mkmp426so/... 형태이면 찾을 수 있다.
    """
    session = requests.Session()
    errors = []

    candidates = [code]

    # 파일명에 suffix가 실제로 있었던 경우를 가장 먼저 보조 후보로 사용.
    if alt_code and alt_code != code:
        candidates.append(alt_code)

    # 파일명에 suffix가 없어도 DMM CDN 쪽 key에는 suffix가 붙는 작품이 있다.
    # 예: MKMP-426 -> mkmp426so
    # 따라서 기본 품번 + 알려진 CDN suffix도 추가로 시도한다.
    for suffix in DMM_CODE_SUFFIX_FALLBACKS:
        fallback_code = f"{code}{suffix}"
        if fallback_code not in candidates:
            candidates.append(fallback_code)

    for candidate_code in candidates:
        for url in dmm_urls(candidate_code):
            try:
                with session.get(
                    url,
                    headers=HEADERS,
                    timeout=REQUEST_TIMEOUT,
                    allow_redirects=True,
                    stream=True
                ) as r:

                    if r.status_code != 200:
                        errors.append(f"{url} -> HTTP {r.status_code}")
                        continue

                    ctype = (r.headers.get("Content-Type") or "").lower()

                    if "image" not in ctype:
                        errors.append(
                            f"{url} -> Content-Type {ctype or '(empty)'}"
                        )
                        continue

                    data = bytearray()

                    for chunk in r.iter_content(64 * 1024):
                        if not chunk:
                            continue

                        data.extend(chunk)

                        if len(data) > MAX_IMAGE_BYTES:
                            data = bytearray()
                            errors.append(f"{url} -> too large")
                            break

                    if len(data) < MIN_IMAGE_BYTES:
                        errors.append(
                            f"{url} -> too small ({len(data)} bytes)"
                        )
                        continue

                    raw = bytes(data)

                    try:
                        with Image.open(io.BytesIO(raw)) as im:
                            im.verify()
                    except Exception as e:
                        errors.append(
                            f"{url} -> invalid image ({type(e).__name__})"
                        )
                        continue

                    # 캐시 키는 화면 표시용 code를 유지
                    return code, raw, url, ""

            except requests.RequestException as e:
                errors.append(
                    f"{url} -> {type(e).__name__}: {e}"
                )

    return (
        code,
        None,
        None,
        " | ".join(errors) if errors else "all DMM patterns failed"
    )



class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title(APP_TITLE)
        self.geometry("1420x900")
        self.minsize(980, 640)

        self.root_dir: Optional[Path] = None
        self.current_dir: Optional[Path] = None

        self.all_items: list[BrowserItem] = []
        self.filtered_items: list[BrowserItem] = []

        self.queue = Queue()
        self.executor = ThreadPoolExecutor(
            max_workers=NETWORK_WORKERS
        )

        self.search_var = tk.StringVar()
        self.auto_var = tk.BooleanVar(value=True)

        # 품번 기준 메모리 캐시.
        # 폴더를 오가더라도 현재 프로그램 실행 동안 재사용한다.
        self.remote_bytes: dict[str, bytes] = {}
        self.remote_urls: dict[str, str] = {}
        self.failed: dict[str, str] = {}
        self.pending: set[str] = set()

        self.photo_cache = {}

        # virtualization
        self.current_cols = 1
        self.visible_windows = {}
        self._visible_update_job = None

        self.scan_generation = 0

        # zoom
        self.zoom_overlay = None
        self.zoom_label = None
        self.zoom_photo = None
        self.zoom_source = None

        self.build_ui()

        self.search_var.trace_add(
            "write",
            lambda *_: self.apply_filter()
        )

        self.after(
            100,
            self.process_queue
        )

    def destroy(self):
        try:
            self.executor.shutdown(
                wait=False,
                cancel_futures=True
            )
        except Exception:
            pass

        super().destroy()

    def build_ui(self):
        top = ttk.Frame(
            self,
            padding=(12, 10)
        )
        top.pack(fill="x")

        ttk.Button(
            top,
            text="폴더 선택",
            command=self.choose_root
        ).pack(side="left")

        self.up_button = ttk.Button(
            top,
            text="↑ 상위 폴더",
            command=self.go_up,
            state="disabled"
        )
        self.up_button.pack(
            side="left",
            padx=(6, 0)
        )

        ttk.Button(
            top,
            text="새로고침",
            command=self.refresh_current
        ).pack(
            side="left",
            padx=(6, 0)
        )

        self.path_var = tk.StringVar(
            value="동영상 루트 폴더를 선택하세요."
        )

        ttk.Label(
            top,
            textvariable=self.path_var
        ).pack(
            side="left",
            padx=12,
            fill="x",
            expand=True
        )

        tools = ttk.Frame(
            self,
            padding=(12, 0, 12, 8)
        )
        tools.pack(fill="x")

        ttk.Label(
            tools,
            text="현재 폴더 검색"
        ).pack(side="left")

        ttk.Entry(
            tools,
            textvariable=self.search_var,
            width=30
        ).pack(
            side="left",
            padx=(6, 12)
        )

        ttk.Checkbutton(
            tools,
            text="화면 주변 DMM 썸네일 자동 확인",
            variable=self.auto_var
        ).pack(side="left")

        ttk.Button(
            tools,
            text="현재 화면 썸네일 확인",
            command=self.fetch_visible_missing
        ).pack(
            side="left",
            padx=(8, 0)
        )

        self.count_var = tk.StringVar(
            value=""
        )

        ttk.Label(
            tools,
            textvariable=self.count_var
        ).pack(side="right")

        outer = ttk.Frame(self)
        outer.pack(
            fill="both",
            expand=True
        )

        self.canvas = tk.Canvas(
            outer,
            highlightthickness=0
        )

        self.vscroll = ttk.Scrollbar(
            outer,
            orient="vertical",
            command=self.on_scrollbar
        )

        self.canvas.configure(
            yscrollcommand=self.vscroll.set
        )

        self.vscroll.pack(
            side="right",
            fill="y"
        )

        self.canvas.pack(
            side="left",
            fill="both",
            expand=True
        )

        self.canvas.bind(
            "<Configure>",
            self.on_canvas
        )

        self.canvas.bind_all(
            "<MouseWheel>",
            self.on_mousewheel
        )

        self.status = tk.StringVar(
            value="대기 중"
        )

        ttk.Label(
            self,
            textvariable=self.status,
            relief="sunken",
            anchor="w",
            padding=(8, 4)
        ).pack(
            fill="x",
            side="bottom"
        )

    # ------------------------------------------------------------------
    # folder navigation
    # ------------------------------------------------------------------

    def choose_root(self):
        folder = filedialog.askdirectory(
            title="동영상 루트 폴더 선택"
        )

        if not folder:
            return

        self.root_dir = Path(folder).resolve()
        self.open_directory(self.root_dir)

    def open_directory(self, folder: Path):
        try:
            folder = folder.resolve()
        except Exception:
            folder = Path(folder)

        # 선택한 루트 밖으로 나가는 것은 막음
        if self.root_dir:
            try:
                folder.relative_to(self.root_dir)
            except ValueError:
                return

        self.close_zoom()

        self.current_dir = folder
        self.path_var.set(str(folder))

        self.search_var.set("")

        self.update_up_button()
        self.load_current_directory()

    def go_up(self):
        if not self.current_dir or not self.root_dir:
            return

        if self.current_dir == self.root_dir:
            return

        self.open_directory(
            self.current_dir.parent
        )

    def update_up_button(self):
        if (
            self.current_dir
            and self.root_dir
            and self.current_dir != self.root_dir
        ):
            self.up_button.configure(
                state="normal"
            )
        else:
            self.up_button.configure(
                state="disabled"
            )

    def refresh_current(self):
        if self.current_dir:
            self.load_current_directory()

    def load_current_directory(self):
        if not self.current_dir:
            return

        self.scan_generation += 1
        generation = self.scan_generation

        self.all_items = []
        self.filtered_items = []

        self.clear_visible_cards()
        self.rebuild_scrollregion()

        self.status.set(
            "현재 폴더 읽는 중..."
        )

        folder = self.current_dir

        threading.Thread(
            target=self.scan_worker,
            args=(generation, folder),
            daemon=True
        ).start()

    def scan_worker(
        self,
        generation: int,
        folder: Path
    ):
        try:
            items = scan_current_directory(
                folder
            )

            self.queue.put(
                (
                    "scan_done",
                    generation,
                    folder,
                    items
                )
            )

        except Exception as e:
            self.queue.put(
                (
                    "error",
                    generation,
                    f"폴더 검색 실패:\n{e}"
                )
            )

    # ------------------------------------------------------------------
    # filtering / virtual layout
    # ------------------------------------------------------------------

    def apply_filter(self):
        q = self.search_var.get().strip().casefold()

        if not q:
            self.filtered_items = list(
                self.all_items
            )
        else:
            # 폴더 먼저, 영상 다음의 원래 순서는 유지
            self.filtered_items = [
                item
                for item in self.all_items
                if (
                    q in item.name.casefold()
                    or q in item.code.casefold()
                )
            ]

        folder_count = sum(
            1
            for x in self.filtered_items
            if x.kind == "folder"
        )

        video_count = sum(
            1
            for x in self.filtered_items
            if x.kind == "video"
        )

        self.count_var.set(
            f"폴더 {folder_count:,} / "
            f"동영상 {video_count:,}"
        )

        self.clear_visible_cards()
        self.rebuild_scrollregion()
        self.canvas.yview_moveto(0)
        self.schedule_visible_update(
            force=True
        )

    def on_scrollbar(self, *args):
        self.canvas.yview(*args)
        self.schedule_visible_update()

    def on_mousewheel(self, event):
        self.canvas.yview_scroll(
            int(-event.delta / 120),
            "units"
        )
        self.schedule_visible_update()

    def on_canvas(self, event):
        cols = max(
            1,
            max(
                event.width - OUTER_PAD * 2,
                CARD_W
            )
            // (CARD_W + GAP_X)
        )

        if cols != self.current_cols:
            self.current_cols = cols
            self.clear_visible_cards()
            self.rebuild_scrollregion()
            self.schedule_visible_update(
                force=True
            )

        else:
            self.rebuild_scrollregion()
            self.schedule_visible_update()

    def rebuild_scrollregion(self):
        count = len(
            self.filtered_items
        )

        rows = (
            (count + self.current_cols - 1)
            // self.current_cols
            if count
            else 1
        )

        total_h = (
            OUTER_PAD * 2
            + rows * CARD_H
            + max(0, rows - 1) * GAP_Y
        )

        total_w = (
            OUTER_PAD * 2
            + self.current_cols * CARD_W
            + max(0, self.current_cols - 1) * GAP_X
        )

        self.canvas.configure(
            scrollregion=(
                0,
                0,
                total_w,
                total_h
            )
        )

    def clear_visible_cards(self):
        for info in self.visible_windows.values():
            try:
                self.canvas.delete(
                    info["window_id"]
                )
                info["frame"].destroy()
            except Exception:
                pass

        self.visible_windows.clear()

        if getattr(
            self,
            "_empty_msg_id",
            None
        ):
            try:
                self.canvas.delete(
                    self._empty_msg_id
                )
                self._empty_msg_widget.destroy()
            except Exception:
                pass

            self._empty_msg_id = None
            self._empty_msg_widget = None

    def schedule_visible_update(
        self,
        force=False
    ):
        if self._visible_update_job:
            try:
                self.after_cancel(
                    self._visible_update_job
                )
            except Exception:
                pass

        delay = (
            1
            if force
            else UPDATE_DEBOUNCE_MS
        )

        self._visible_update_job = self.after(
            delay,
            self.update_visible_cards
        )

    def visible_index_range(self):
        if not self.filtered_items:
            return 0, -1

        top_y = self.canvas.canvasy(0)

        bottom_y = (
            top_y
            + self.canvas.winfo_height()
        )

        row_span = (
            CARD_H
            + GAP_Y
        )

        first_row = max(
            0,
            int(
                (top_y - OUTER_PAD)
                // row_span
            )
        )

        last_row = max(
            0,
            int(
                (bottom_y - OUTER_PAD)
                // row_span
            )
        )

        first_idx = (
            first_row
            * self.current_cols
        )

        last_idx = min(
            len(self.filtered_items) - 1,
            (
                (last_row + 1)
                * self.current_cols
            ) - 1
        )

        start = max(
            0,
            first_idx
            - VISIBLE_BUFFER_ITEMS
        )

        end = min(
            len(self.filtered_items) - 1,
            last_idx
            + VISIBLE_BUFFER_ITEMS
        )

        return start, end

    def update_visible_cards(self):
        self._visible_update_job = None

        if not self.filtered_items:
            self.show_empty_message()
            return

        self.remove_empty_message()

        start, end = self.visible_index_range()

        needed = set(
            range(start, end + 1)
        )

        # 범위 밖 카드 제거
        for idx in list(
            self.visible_windows.keys()
        ):
            if idx in needed:
                continue

            info = self.visible_windows.pop(
                idx
            )

            try:
                self.canvas.delete(
                    info["window_id"]
                )
                info["frame"].destroy()
            except Exception:
                pass

        # 새 범위 카드 생성
        for idx in sorted(needed):
            if idx in self.visible_windows:
                continue

            self.create_card_window(
                idx
            )

        if self.auto_var.get():
            self.fetch_visible_missing()

    # ------------------------------------------------------------------
    # cards
    # ------------------------------------------------------------------

    def create_card_window(self, idx):
        item = self.filtered_items[idx]

        row = (
            idx
            // self.current_cols
        )

        col = (
            idx
            % self.current_cols
        )

        x = (
            OUTER_PAD
            + col * (
                CARD_W + GAP_X
            )
        )

        y = (
            OUTER_PAD
            + row * (
                CARD_H + GAP_Y
            )
        )

        card = ttk.Frame(
            self.canvas,
            relief="ridge",
            borderwidth=1,
            padding=8,
            width=CARD_W,
            height=CARD_H
        )
        card.pack_propagate(False)

        cover = ttk.Label(
            card,
            anchor="center",
            cursor="hand2"
        )
        cover.pack()

        if item.kind == "folder":
            ph_key = "__folder_placeholder__"

            if ph_key not in self.photo_cache:
                self.photo_cache[
                    ph_key
                ] = ImageTk.PhotoImage(
                    folder_placeholder()
                )

            cover.configure(
                image=self.photo_cache[
                    ph_key
                ]
            )
            cover.image = self.photo_cache[
                ph_key
            ]

            cover.bind(
                "<Button-1>",
                lambda e, p=item.path:
                    self.open_directory(p)
            )

            ttk.Label(
                card,
                text="📁 " + item.name,
                font=(
                    "Segoe UI",
                    11,
                    "bold"
                ),
                anchor="center"
            ).pack(
                fill="x",
                pady=(7, 5)
            )

            ttk.Label(
                card,
                text="하위 폴더",
                anchor="center"
            ).pack(
                fill="x",
                pady=(0, 9)
            )

            ttk.Button(
                card,
                text="폴더 열기",
                command=lambda p=item.path:
                    self.open_directory(p)
            ).pack(
                fill="x"
            )

        else:
            # video image
            cover_source = None

            if (
                item.local_image
                and item.local_image.exists()
            ):
                self.set_file_cover(
                    cover,
                    item.local_image,
                    f"local:{item.path}"
                )

                cover_source = (
                    "file",
                    item.local_image
                )

            elif (
                item.code
                in self.remote_bytes
            ):
                raw = self.remote_bytes[
                    item.code
                ]

                self.set_bytes_cover(
                    cover,
                    raw,
                    item.code
                )

                cover_source = (
                    "bytes",
                    raw
                )

            else:
                ph = ImageTk.PhotoImage(
                    placeholder_image(
                        "LOADING"
                        if item.code
                        in self.pending
                        else "NO COVER"
                    )
                )

                cover.configure(
                    image=ph
                )
                cover.image = ph

            if cover_source:
                cover.bind(
                    "<Button-1>",
                    lambda e, src=cover_source:
                        self.open_zoom(src)
                )

            ttk.Label(
                card,
                text=(
                    item.code
                    or "코드 없음"
                ),
                font=(
                    "Segoe UI",
                    11,
                    "bold"
                ),
                anchor="center"
            ).pack(
                fill="x",
                pady=(7, 2)
            )

            filename = (
                item.name
                if len(item.name) <= 31
                else item.name[:28]
                + "..."
            )

            ttk.Label(
                card,
                text=filename,
                width=30,
                anchor="center"
            ).pack(fill="x")

            ttk.Label(
                card,
                text="현재 폴더",
                width=30,
                anchor="center"
            ).pack(
                fill="x",
                pady=(2, 7)
            )

            buttons = ttk.Frame(
                card
            )
            buttons.pack(fill="x")

            ttk.Button(
                buttons,
                text="▶ 재생",
                command=lambda p=item.path:
                    self.open_path(p)
            ).pack(
                side="left",
                expand=True,
                fill="x"
            )

            ttk.Button(
                buttons,
                text="폴더",
                command=lambda p=item.path.parent:
                    self.open_path(p)
            ).pack(
                side="left",
                expand=True,
                fill="x",
                padx=(5, 0)
            )


        window_id = self.canvas.create_window(
            x,
            y,
            window=card,
            anchor="nw",
            width=CARD_W,
            height=CARD_H
        )

        self.visible_windows[idx] = {
            "window_id": window_id,
            "frame": card,
            "cover": cover,
            "item": item
        }

    def show_empty_message(self):
        if getattr(
            self,
            "_empty_msg_id",
            None
        ):
            return

        lbl = ttk.Label(
            self.canvas,
            text="현재 폴더에 표시할 항목이 없습니다."
        )

        self._empty_msg_widget = lbl

        self._empty_msg_id = (
            self.canvas.create_window(
                40,
                40,
                window=lbl,
                anchor="nw"
            )
        )

    def remove_empty_message(self):
        if not getattr(
            self,
            "_empty_msg_id",
            None
        ):
            return

        try:
            self.canvas.delete(
                self._empty_msg_id
            )
            self._empty_msg_widget.destroy()
        except Exception:
            pass

        self._empty_msg_id = None
        self._empty_msg_widget = None

    # ------------------------------------------------------------------
    # images / DMM
    # ------------------------------------------------------------------

    def set_file_cover(
        self,
        label,
        path,
        key
    ):
        if key not in self.photo_cache:
            try:
                with Image.open(
                    path
                ) as im:
                    self.photo_cache[
                        key
                    ] = ImageTk.PhotoImage(
                        contain_image(
                            im,
                            COVER_W,
                            COVER_H
                        )
                    )

            except Exception:
                return False

        label.configure(
            image=self.photo_cache[
                key
            ]
        )

        label.image = self.photo_cache[
            key
        ]

        return True

    def set_bytes_cover(
        self,
        label,
        raw,
        code
    ):
        key = "dmm:" + code

        if key not in self.photo_cache:
            try:
                with Image.open(
                    io.BytesIO(raw)
                ) as im:
                    self.photo_cache[
                        key
                    ] = ImageTk.PhotoImage(
                        contain_image(
                            im,
                            COVER_W,
                            COVER_H
                        )
                    )

            except Exception:
                return False

        label.configure(
            image=self.photo_cache[
                key
            ]
        )

        label.image = self.photo_cache[
            key
        ]

        return True

    def fetch_visible_missing(self):
        if not self.filtered_items:
            return

        start, end = self.visible_index_range()

        unique = {}

        for item in self.filtered_items[
            start:end + 1
        ]:
            if (
                item.kind == "video"
                and item.code
            ):
                unique.setdefault(
                    item.code,
                    item
                )

        scheduled = 0

        for code, item in unique.items():
            if (
                item.local_image
                or code in self.remote_bytes
                or code in self.failed
                or code in self.pending
            ):
                continue

            self.pending.add(code)
            scheduled += 1

            future = self.executor.submit(
                fetch_dmm_image,
                code,
                item.dmm_alt_code
            )

            def done_callback(
                f,
                code=code
            ):
                try:
                    result = f.result()
                except Exception as e:
                    result = (
                        code,
                        None,
                        None,
                        f"worker error: "
                        f"{type(e).__name__}: {e}"
                    )

                self.queue.put(
                    (
                        "thumb_done",
                        *result
                    )
                )

            future.add_done_callback(
                done_callback
            )

        if scheduled:
            self.status.set(
                f"현재 화면 DMM 썸네일 "
                f"{scheduled:,}개 확인 중..."
            )

    def update_visible_code_cards(
        self,
        code,
        raw
    ):
        for info in self.visible_windows.values():
            item = info["item"]

            if (
                item.kind != "video"
                or item.code != code
            ):
                continue

            label = info["cover"]

            self.set_bytes_cover(
                label,
                raw,
                code
            )

            label.configure(
                cursor="hand2"
            )

            label.bind(
                "<Button-1>",
                lambda e, src=("bytes", raw):
                    self.open_zoom(src)
            )

        self.schedule_visible_update(
            force=True
        )

    # ------------------------------------------------------------------
    # queue
    # ------------------------------------------------------------------

    def process_queue(self):
        try:
            while True:
                msg = self.queue.get_nowait()
                kind = msg[0]

                if kind == "scan_done":
                    (
                        _,
                        generation,
                        folder,
                        items
                    ) = msg

                    if (
                        generation
                        != self.scan_generation
                    ):
                        continue

                    if (
                        self.current_dir
                        and folder.resolve()
                        != self.current_dir.resolve()
                    ):
                        continue

                    self.all_items = items

                    folder_count = sum(
                        1
                        for x in items
                        if x.kind == "folder"
                    )

                    video_count = sum(
                        1
                        for x in items
                        if x.kind == "video"
                    )

                    self.status.set(
                        f"현재 폴더 - "
                        f"폴더 {folder_count:,}개 / "
                        f"동영상 {video_count:,}개"
                    )

                    self.apply_filter()

                elif kind == "thumb_done":
                    (
                        _,
                        code,
                        raw,
                        url,
                        err
                    ) = msg

                    self.pending.discard(
                        code
                    )

                    if raw:
                        self.remote_bytes[
                            code
                        ] = raw

                        self.remote_urls[
                            code
                        ] = (
                            url or ""
                        )

                        self.update_visible_code_cards(
                            code,
                            raw
                        )

                    else:
                        self.failed[
                            code
                        ] = (
                            err or "not found"
                        )

                        self.schedule_visible_update(
                            force=True
                        )

                elif kind == "error":
                    (
                        _,
                        generation,
                        text
                    ) = msg

                    if (
                        generation
                        == self.scan_generation
                    ):
                        messagebox.showerror(
                            APP_TITLE,
                            text
                        )

        except Empty:
            pass

        self.after(
            100,
            self.process_queue
        )

    # ------------------------------------------------------------------
    # zoom
    # ------------------------------------------------------------------

    def open_zoom(self, source):
        if self.zoom_overlay is not None:
            self.close_zoom()
            return

        self.zoom_source = source

        overlay = tk.Frame(
            self,
            bg="black"
        )

        overlay.place(
            x=0,
            y=0,
            relwidth=1,
            relheight=1
        )

        overlay.lift()

        label = tk.Label(
            overlay,
            bg="black",
            cursor="hand2"
        )

        label.pack(
            fill="both",
            expand=True
        )

        hint = tk.Label(
            overlay,
            text="이미지를 다시 클릭하면 돌아갑니다",
            fg="white",
            bg="black",
            font=(
                "Segoe UI",
                10
            )
        )

        hint.place(
            relx=0.5,
            rely=0.985,
            anchor="s"
        )

        self.zoom_overlay = overlay
        self.zoom_label = label

        label.bind(
            "<Button-1>",
            lambda e:
                self.close_zoom()
        )

        overlay.bind(
            "<Button-1>",
            lambda e:
                self.close_zoom()
        )

        self.bind(
            "<Escape>",
            lambda e:
                self.close_zoom()
        )

        overlay.bind(
            "<Configure>",
            lambda e:
                self.refresh_zoom_image(
                    e.width,
                    e.height
                )
        )

        self.after(
            20,
            lambda:
                self.refresh_zoom_image(
                    max(
                        100,
                        self.winfo_width()
                    ),
                    max(
                        100,
                        self.winfo_height()
                    )
                )
        )

    def refresh_zoom_image(
        self,
        width,
        height
    ):
        if (
            not self.zoom_overlay
            or not self.zoom_source
        ):
            return

        target_w = max(
            100,
            width - 80
        )

        target_h = max(
            100,
            height - 80
        )

        try:
            kind, value = self.zoom_source

            if kind == "file":
                with Image.open(
                    value
                ) as im:
                    shown = contain_image(
                        im,
                        target_w,
                        target_h,
                        bg=(0, 0, 0)
                    )

            else:
                with Image.open(
                    io.BytesIO(value)
                ) as im:
                    shown = contain_image(
                        im,
                        target_w,
                        target_h,
                        bg=(0, 0, 0)
                    )

            photo = ImageTk.PhotoImage(
                shown
            )

            self.zoom_photo = photo

            self.zoom_label.configure(
                image=photo
            )

        except Exception:
            self.close_zoom()

    def close_zoom(self):
        if self.zoom_overlay is not None:
            try:
                self.zoom_overlay.destroy()
            except Exception:
                pass

        self.zoom_overlay = None
        self.zoom_label = None
        self.zoom_photo = None
        self.zoom_source = None

        try:
            self.unbind(
                "<Escape>"
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # OS
    # ------------------------------------------------------------------

    def open_path(self, path):
        try:
            os.startfile(
                str(path)
            )
        except Exception as e:
            messagebox.showerror(
                APP_TITLE,
                f"열기 실패:\n{e}"
            )


def main():
    App().mainloop()


if __name__ == "__main__":
    main()
