﻿JAV Video Manager v0.7.0 - Folder Browser

주요 변경
=========

이제 선택한 루트 아래의 모든 영상을 한 화면에 펼치지 않습니다.

현재 폴더 단위로 탐색합니다.

표시 순서
=========
1. 현재 폴더의 하위 폴더
   - 이름순 정렬

2. 현재 폴더에 직접 존재하는 동영상
   - 이름순 정렬

하위 폴더 안의 동영상은 해당 폴더를 들어가기 전에는 표시하지 않습니다.

사용 방법
=========
- 폴더 카드를 클릭하거나 "폴더 열기" 버튼을 누르면 해당 폴더로 들어갑니다.
- 상단의 "↑ 상위 폴더" 버튼으로 이전 폴더로 돌아갑니다.
- 처음 선택한 루트 폴더보다 위로는 이동하지 않습니다.
- 상단 경로에 현재 보고 있는 폴더가 표시됩니다.

기존 기능 유지
==============
- DMM CDN 직접 썸네일 확인
- 이미지는 디스크에 저장하지 않고 메모리에서만 표시
- 현재 화면 ±10개 범위만 DMM 썸네일 로딩
- 화면 밖 카드는 제거하는 가상화 UI
- 이미지 전체 비율 표시
- 이미지 클릭 확대
- 확대 이미지 다시 클릭 / ESC로 닫기
- 재생 버튼 / Windows 폴더 열기

성능상 이점
===========
예를 들어 루트 아래에 1,200개의 영상이 있어도
루트 폴더에 하위 폴더 15개와 직접 들어있는 영상 3개만 있다면
첫 화면에는 18개 항목만 처리합니다.

하위 폴더 안의 영상은 그 폴더에 들어갔을 때만 읽고 표시합니다.


v0.7.1 추가 변경
================
DMM 이미지 검색 패턴에 아래 CDN 구조를 추가했습니다.

https://pics.dmm.co.jp/mono/movie/adult/125{key}/125{key}pl.jpg

예:
UMD-903 -> key: umd903
https://pics.dmm.co.jp/mono/movie/adult/125umd903/125umd903pl.jpg

현재 DMM URL 검사 순서
======================
1. https://pics.dmm.co.jp/mono/movie/adult/1{key}/1{key}pl.jpg
2. https://pics.dmm.co.jp/mono/movie/adult/h_1100{key}r/h_1100{key}rpl.jpg
3. https://pics.dmm.co.jp/mono/movie/adult/{key}/{key}pl.jpg
4. https://pics.dmm.co.jp/mono/movie/adult/125{key}/125{key}pl.jpg


v0.7.2 추가 변경
================
DMM 이미지 URL 생성 규칙을 더 확장했습니다.

1) h_ 접두사 다른 변형 추가
---------------------------
이제 아래 형태를 자동으로 시도합니다.

- h_1100{key}r / h_1100{key}
- h_84{key}r / h_84{key}
- h_084{key}r / h_084{key}
- h_118{key}r / h_118{key}
- h_55{key}r / h_55{key}
- h_055{key}r / h_055{key}
- h_125{key}r / h_125{key}
- h_{key}r / h_{key}

2) 제조사별 prefix 패턴 자동 확장
--------------------------------
이제 아래 prefix도 자동으로 시도합니다.

- 84{key}
- 118{key}
- 55{key}

즉, 일반 패턴은 다음과 같이 검사합니다.

- 1{key}
- {key}
- 125{key}
- 84{key}
- 118{key}
- 55{key}

예시
====
UMD-903 -> key = umd903

일반 패턴 예:
- https://pics.dmm.co.jp/mono/movie/adult/125umd903/125umd903pl.jpg
- https://pics.dmm.co.jp/mono/movie/adult/84umd903/84umd903pl.jpg
- https://pics.dmm.co.jp/mono/movie/adult/118umd903/118umd903pl.jpg
- https://pics.dmm.co.jp/mono/movie/adult/55umd903/55umd903pl.jpg

h_ 패턴 예:
- https://pics.dmm.co.jp/mono/movie/adult/h_1100umd903r/h_1100umd903rpl.jpg
- https://pics.dmm.co.jp/mono/movie/adult/h_84umd903r/h_84umd903rpl.jpg
- https://pics.dmm.co.jp/mono/movie/adult/h_084umd903/h_084umd903pl.jpg


v0.7.3 추가 변경
================
DMM 일반 prefix 패턴에 아래 구조를 추가했습니다.

- 41{key}

예:
HODV-22080 -> key = hodv22080
https://pics.dmm.co.jp/mono/movie/adult/41hodv22080/41hodv22080pl.jpg

참고
====
품번이 HODV22080처럼 글자+숫자가 길어도
기존 품번 추출 규칙으로 정상 인식됩니다.
즉,

- HODV22080
- HODV-22080
- hodv_22080

모두 HODV-22080 형식으로 정규화됩니다.


v0.7.4 추가 변경
================
숫자 뒤에 영문 suffix가 붙는 품번을 지원합니다.

예:
URKK051SO
URKK-051SO
urkk_051so

모두:
URKK-051SO

로 정규화됩니다.

DMM key:
URKK-051SO -> urkk051so

따라서 아래 URL 패턴을 정상 생성합니다.

https://pics.dmm.co.jp/mono/movie/adult/urkk051so/urkk051sopl.jpg

이전 버전에서는 URKK051SO를 URKK-051까지만 인식할 수 있어
urkk051/urkk051pl.jpg를 조회했고,
따라서 이런 suffix 품번의 썸네일을 찾지 못할 수 있었습니다.


v0.7.5 변경
===========

- 카드의 `DMM ✓`, `DMM 없음` 표시 제거
- 품번은 영문 + 숫자 조합까지만 인식
- 숫자 뒤에 붙는 영문은 품번에서 제외

예:
URKK051SO -> URKK-051
URKK-051SO -> URKK-051
URKK_051VR -> URKK-051
ABC123R -> ABC-123

즉 숫자 뒤의 SO / R / VR 등은 파일명 부가 문자열로 취급합니다.


v0.7.6 수정
===========

이전 설명을 명확하게 수정했습니다.

이번 예외 처리는 DMM 이미지 검색 규칙을 바꾸는 것이 아닙니다.
DMM CDN 후보 URL 생성 방식과 prefix 확장 규칙은 v0.7.4~v0.7.5 방식 그대로 유지합니다.

변경되는 것은 "영상 파일명에서 품번을 읽는 단계"뿐입니다.

파일명 예:
JKK-500CH.mp4
JKK500CH.mp4
jkk_500ch.mkv

위 파일들은 숫자 뒤 CH를 파일명 부가 문자열로 보고:

JKK-500

만 품번으로 추출합니다.

다른 예:
URKK051SO.mp4 -> URKK-051
ABC123R.mkv   -> ABC-123

그 다음 추출된 JKK-500, URKK-051 등의 품번을 기존 DMM URL 생성 알고리즘에 그대로 넘깁니다.

즉:
파일명 정리 -> 품번 추출 -> 기존 DMM URL 패턴 검사

순서입니다.

카드의 DMM 체크/없음 마크는 v0.7.5와 동일하게 표시하지 않습니다.


v0.7.7 수정
===========

MKMP426SO 같은 파일명 대응을 수정했습니다.

핵심은 "화면에 표시하는 품번"과 "DMM에서 실제로 시도하는 검색 후보"를 분리한 것입니다.

예:
MKMP426SO.mp4

화면 표시:
MKMP-426

DMM 검색:
1차: 기존 규칙 그대로 MKMP-426 -> mkmp426
2차: 1차가 모두 실패하면 파일명 suffix를 포함한 MKMP-426SO -> mkmp426so

따라서 다음과 같은 실제 DMM 주소도 찾을 수 있습니다.

https://pics.dmm.co.jp/mono/movie/adult/mkmp426so/mkmp426sopl.jpg

중요:
- 품번 표시는 여전히 영어+숫자까지만입니다.
- 숫자 뒤 SO는 표시 품번으로 취급하지 않습니다.
- DMM URL 패턴 알고리즘(prefix 1/125/84/118/55/41, h_ 변형 등)은 그대로입니다.
- suffix 포함 문자열은 DMM 검색의 '보조 후보'로만 사용합니다.


v0.7.9 수정
===========

MKMP-426 / MKMP-441처럼 "영상 파일명에는 SO가 없지만
DMM CDN 이미지 key에는 SO가 붙는" 케이스를 추가 대응했습니다.

이전 v0.7.7의 한계:
-------------------
파일명:
MKMP-426.mp4

표시 품번:
MKMP-426

파일명에 SO가 없으므로 보조 후보 MKMP-426SO를 만들지 않았습니다.
따라서 실제 이미지가 아래처럼 존재해도 찾지 못했습니다.

https://pics.dmm.co.jp/mono/movie/adult/mkmp426so/mkmp426sopl.jpg

v0.7.9 검색 순서:
-----------------
1. 기본 품번
   MKMP-426 -> mkmp426

2. 파일명에서 suffix가 발견된 경우
   예: MKMP426CH -> mkmp426ch

3. 파일명에 suffix가 없어도 알려진 DMM CDN suffix 후보 추가
   MKMP-426SO -> mkmp426so

각 후보에 대해서는 기존 DMM URL 패턴
(1 / 기본 / 125 / 84 / 118 / 55 / 41 / h_ 변형)을 그대로 사용합니다.

화면 표시 품번은 계속 MKMP-426처럼 영문+숫자까지만 유지합니다.
