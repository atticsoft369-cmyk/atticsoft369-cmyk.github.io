﻿# JAV Video Manager v1.0 - Windows No-Python Edition
# Requires only Windows PowerShell 5.1 / .NET Framework included with Windows.
# No Python, pip, requests, Pillow, Selenium, or separate runtime installation.

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$source = @'
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

public class BrowserItem
{
    public bool IsFolder;
    public string Name;
    public string Path;
    public string Code;
    public string AltCode;
    public string LocalImage;
}

public class NaturalComparer : IComparer<BrowserItem>
{
    public int Compare(BrowserItem a, BrowserItem b)
    {
        if (a.IsFolder != b.IsFolder)
            return a.IsFolder ? -1 : 1;

        return CompareNatural(Clean(a.Name), Clean(b.Name));
    }

    private string Clean(string s)
    {
        if (String.IsNullOrEmpty(s)) return "";
        s = s.Trim();

        int start = 0;
        while (start < s.Length && !Char.IsLetterOrDigit(s[start])) start++;

        int end = s.Length - 1;
        while (end >= start && !Char.IsLetterOrDigit(s[end])) end--;

        if (end < start) return "";
        return s.Substring(start, end - start + 1);
    }

    private int CompareNatural(string a, string b)
    {
        int ia = 0, ib = 0;

        while (ia < a.Length && ib < b.Length)
        {
            bool da = Char.IsDigit(a[ia]);
            bool db = Char.IsDigit(b[ib]);

            if (da && db)
            {
                int sa = ia, sb = ib;
                while (ia < a.Length && Char.IsDigit(a[ia])) ia++;
                while (ib < b.Length && Char.IsDigit(b[ib])) ib++;

                string na = a.Substring(sa, ia - sa).TrimStart('0');
                string nb = b.Substring(sb, ib - sb).TrimStart('0');

                if (na.Length == 0) na = "0";
                if (nb.Length == 0) nb = "0";

                if (na.Length != nb.Length)
                    return na.Length.CompareTo(nb.Length);

                int nc = String.CompareOrdinal(na, nb);
                if (nc != 0) return nc;
            }
            else
            {
                char ca = Char.ToUpperInvariant(a[ia]);
                char cb = Char.ToUpperInvariant(b[ib]);

                if (ca != cb)
                    return ca.CompareTo(cb);

                ia++;
                ib++;
            }
        }

        return (a.Length - ia).CompareTo(b.Length - ib);
    }
}

public class MainForm : Form
{
    const int CardWidth = 250;
    const int CardHeight = 310;
    const int CoverWidth = 220;
    const int CoverHeight = 165;
    const int BufferItems = 10;
    const int MaxWorkers = 6;

    static readonly string[] VideoExts = new string[] {
        ".mp4",".mkv",".avi",".wmv",".mov",".m4v",".flv",
        ".ts",".m2ts",".webm",".mpg",".mpeg"
    };

    static readonly string[] ImageExts = new string[] {
        ".jpg",".jpeg",".png",".webp",".bmp"
    };

    static readonly Regex CodeRegex = new Regex(
        @"(?i)(?<![A-Z0-9])([A-Z]{2,20})[-_ .]*(\d{2,8})([A-Z]{0,6})(?![A-Z0-9])",
        RegexOptions.Compiled
    );

    readonly HttpClient http = new HttpClient();
    readonly SemaphoreSlim networkGate = new SemaphoreSlim(MaxWorkers);

    readonly Dictionary<string, byte[]> remoteBytes =
        new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);

    readonly HashSet<string> failedCodes =
        new HashSet<string>(StringComparer.OrdinalIgnoreCase);

    readonly HashSet<string> pendingCodes =
        new HashSet<string>(StringComparer.OrdinalIgnoreCase);

    readonly Dictionary<Panel, BrowserItem> cardItems =
        new Dictionary<Panel, BrowserItem>();

    readonly object networkLock = new object();

    List<BrowserItem> allItems = new List<BrowserItem>();
    List<BrowserItem> filteredItems = new List<BrowserItem>();

    string rootDir = null;
    string currentDir = null;
    string folderSnapshot = null;
    bool reloadPending = false;

    Panel topPanel;
    Button chooseButton;
    Button upButton;
    Button refreshButton;
    Label pathLabel;

    Panel toolPanel;
    Label searchLabel;
    TextBox searchBox;
    CheckBox autoThumbCheck;
    Button visibleThumbButton;
    Label countLabel;
    Label brandLabel;

    FlowLayoutPanel flow;
    StatusStrip statusStrip;
    ToolStripStatusLabel statusLabel;

    System.Windows.Forms.Timer folderWatchTimer;
    System.Windows.Forms.Timer visibleTimer;

    Panel zoomOverlay;
    PictureBox zoomPicture;
    Image zoomImage;

    Image folderIcon;
    Image noCoverIcon;

    public MainForm()
    {
        Text = "JAV Video Manager v1.0.4 - AtticSoft Presents";
        Width = 1440;
        Height = 920;
        MinimumSize = new Size(980, 640);
        StartPosition = FormStartPosition.CenterScreen;

        http.Timeout = TimeSpan.FromSeconds(10);
        http.DefaultRequestHeaders.UserAgent.ParseAdd(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/151 Safari/537.36"
        );
        http.DefaultRequestHeaders.Referrer = new Uri("https://www.dmm.co.jp/");

        folderIcon = MakeFolderIcon();
        noCoverIcon = MakeNoCoverIcon();

        // UI 생성 중 FlowLayoutPanel.Resize 이벤트가 발생할 수 있으므로
        // 이벤트가 참조하는 Timer를 먼저 생성한다.
        visibleTimer = new System.Windows.Forms.Timer();
        visibleTimer.Interval = 120;
        visibleTimer.Tick += delegate {
            visibleTimer.Stop();
            QueueVisibleThumbnails();
        };

        folderWatchTimer = new System.Windows.Forms.Timer();
        folderWatchTimer.Interval = 1500;
        folderWatchTimer.Tick += delegate { WatchCurrentFolder(); };

        BuildUi();

        folderWatchTimer.Start();

        FormClosed += delegate {
            try { folderWatchTimer.Stop(); } catch {}
            try { visibleTimer.Stop(); } catch {}
            try { http.Dispose(); } catch {}
            try { networkGate.Dispose(); } catch {}
            try { if (folderIcon != null) folderIcon.Dispose(); } catch {}
            try { if (noCoverIcon != null) noCoverIcon.Dispose(); } catch {}
        };
    }

    void BuildUi()
    {
        topPanel = new Panel();
        topPanel.Dock = DockStyle.Top;
        topPanel.Height = 42;
        Controls.Add(topPanel);

        chooseButton = new Button();
        chooseButton.Text = "폴더 선택";
        chooseButton.SetBounds(12, 8, 86, 27);
        chooseButton.Click += delegate { ChooseRoot(); };
        topPanel.Controls.Add(chooseButton);

        upButton = new Button();
        upButton.Text = "↑ 상위 폴더";
        upButton.SetBounds(105, 8, 90, 27);
        upButton.Enabled = false;
        upButton.Click += delegate { GoUp(); };
        topPanel.Controls.Add(upButton);

        refreshButton = new Button();
        refreshButton.Text = "새로고침";
        refreshButton.SetBounds(202, 8, 86, 27);
        refreshButton.Click += delegate { LoadCurrentDirectory(); };
        topPanel.Controls.Add(refreshButton);

        pathLabel = new Label();
        pathLabel.AutoEllipsis = true;
        pathLabel.Text = "동영상 루트 폴더를 선택하세요.";
        pathLabel.SetBounds(302, 13, 1000, 21);
        pathLabel.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
        topPanel.Controls.Add(pathLabel);

        toolPanel = new Panel();
        toolPanel.Dock = DockStyle.Top;
        toolPanel.Height = 42;
        Controls.Add(toolPanel);

        searchLabel = new Label();
        searchLabel.Text = "현재 폴더 검색";
        searchLabel.AutoSize = true;
        searchLabel.Location = new Point(12, 13);
        toolPanel.Controls.Add(searchLabel);

        searchBox = new TextBox();
        searchBox.SetBounds(100, 9, 220, 25);
        searchBox.TextChanged += delegate { ApplyFilter(); };
        toolPanel.Controls.Add(searchBox);

        autoThumbCheck = new CheckBox();
        autoThumbCheck.Text = "화면 주변 DMM 썸네일 자동 확인";
        autoThumbCheck.Checked = true;
        autoThumbCheck.AutoSize = true;
        autoThumbCheck.Location = new Point(334, 11);
        autoThumbCheck.CheckedChanged += delegate {
            if (autoThumbCheck.Checked) ScheduleVisibleThumbCheck();
        };
        toolPanel.Controls.Add(autoThumbCheck);

        visibleThumbButton = new Button();
        visibleThumbButton.Text = "현재 화면 썸네일 확인";
        visibleThumbButton.SetBounds(548, 7, 135, 28);
        visibleThumbButton.Click += delegate { QueueVisibleThumbnails(); };
        toolPanel.Controls.Add(visibleThumbButton);

        countLabel = new Label();
        countLabel.TextAlign = ContentAlignment.MiddleRight;
        countLabel.SetBounds(1030, 10, 250, 24);
        countLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        toolPanel.Controls.Add(countLabel);

        // atticsoft brand mark - UI upper-right corner
        brandLabel = new Label();
        brandLabel.Text = "atticsoft";
        brandLabel.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
        brandLabel.ForeColor = Color.DimGray;
        brandLabel.TextAlign = ContentAlignment.MiddleRight;
        brandLabel.SetBounds(1285, 9, 105, 24);
        brandLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        brandLabel.Cursor = Cursors.Default;
        toolPanel.Controls.Add(brandLabel);

        statusStrip = new StatusStrip();
        statusLabel = new ToolStripStatusLabel();
        statusLabel.Spring = true;
        statusLabel.TextAlign = ContentAlignment.MiddleLeft;
        statusLabel.Text = "대기 중";
        statusStrip.Items.Add(statusLabel);
        Controls.Add(statusStrip);

        flow = new FlowLayoutPanel();
        flow.Dock = DockStyle.Fill;
        flow.AutoScroll = true;
        flow.WrapContents = true;
        flow.Padding = new Padding(12);
        flow.BackColor = SystemColors.Control;
        flow.Scroll += delegate { ScheduleVisibleThumbCheck(); };
        flow.Resize += delegate { ScheduleVisibleThumbCheck(); };
        Controls.Add(flow);

        flow.BringToFront();
    }

    void ChooseRoot()
    {
        using (FolderBrowserDialog dlg = new FolderBrowserDialog())
        {
            dlg.Description = "동영상 루트 폴더 선택";
            dlg.ShowNewFolderButton = false;

            if (dlg.ShowDialog(this) != DialogResult.OK)
                return;

            rootDir = Path.GetFullPath(dlg.SelectedPath);
            OpenDirectory(rootDir);
        }
    }

    void GoUp()
    {
        if (String.IsNullOrEmpty(currentDir) || String.IsNullOrEmpty(rootDir))
            return;

        if (PathsEqual(currentDir, rootDir))
            return;

        DirectoryInfo di = Directory.GetParent(currentDir);
        if (di == null) return;

        OpenDirectory(di.FullName);
    }

    bool PathsEqual(string a, string b)
    {
        return String.Equals(
            Path.GetFullPath(a).TrimEnd('\\'),
            Path.GetFullPath(b).TrimEnd('\\'),
            StringComparison.OrdinalIgnoreCase
        );
    }

    bool IsInsideRoot(string folder)
    {
        if (String.IsNullOrEmpty(rootDir)) return false;

        string root = Path.GetFullPath(rootDir).TrimEnd('\\') + "\\";
        string full = Path.GetFullPath(folder).TrimEnd('\\') + "\\";

        return full.StartsWith(root, StringComparison.OrdinalIgnoreCase)
            || PathsEqual(folder, rootDir);
    }

    void OpenDirectory(string folder)
    {
        if (!Directory.Exists(folder))
        {
            statusLabel.Text = "폴더가 삭제되었거나 존재하지 않습니다.";
            LoadCurrentDirectory();
            return;
        }

        if (!IsInsideRoot(folder))
            return;

        CloseZoom();

        currentDir = Path.GetFullPath(folder);
        pathLabel.Text = currentDir;
        upButton.Enabled = !PathsEqual(currentDir, rootDir);

        if (searchBox.Text.Length > 0)
            searchBox.Text = "";

        LoadCurrentDirectory();
    }

    async void LoadCurrentDirectory()
    {
        if (String.IsNullOrEmpty(currentDir))
            return;

        if (!Directory.Exists(currentDir))
        {
            HandleCurrentFolderDeleted();
            return;
        }

        reloadPending = true;
        string folder = currentDir;
        statusLabel.Text = "현재 폴더 읽는 중...";

        try
        {
            List<BrowserItem> items = await Task.Run(() => ScanCurrentDirectory(folder));

            if (!String.Equals(folder, currentDir, StringComparison.OrdinalIgnoreCase))
                return;

            allItems = items;
            folderSnapshot = MakeFolderSnapshot(folder);
            reloadPending = false;

            ApplyFilter();

            int folderCount = items.Count(x => x.IsFolder);
            int videoCount = items.Count(x => !x.IsFolder);

            statusLabel.Text = String.Format(
                "현재 폴더 - 폴더 {0}개 / 동영상 {1}개",
                folderCount,
                videoCount
            );
        }
        catch (Exception ex)
        {
            reloadPending = false;
            statusLabel.Text = "폴더 읽기 실패";
            MessageBox.Show(
                this,
                "폴더를 읽는 중 오류가 발생했습니다.\r\n\r\n" + ex.Message,
                Text,
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
        }
    }

    List<BrowserItem> ScanCurrentDirectory(string folder)
    {
        string[] entries = Directory.GetFileSystemEntries(folder);

        List<string> imageFiles = entries
            .Where(p => File.Exists(p) && ImageExts.Contains(
                Path.GetExtension(p).ToLowerInvariant()
            ))
            .ToList();

        List<BrowserItem> result = new List<BrowserItem>();

        foreach (string p in entries)
        {
            if (Directory.Exists(p))
            {
                result.Add(new BrowserItem {
                    IsFolder = true,
                    Name = Path.GetFileName(p),
                    Path = p,
                    Code = "",
                    AltCode = "",
                    LocalImage = null
                });
                continue;
            }

            if (!File.Exists(p))
                continue;

            string ext = Path.GetExtension(p).ToLowerInvariant();
            if (!VideoExts.Contains(ext))
                continue;

            string code;
            string alt;
            ExtractCodeInfo(Path.GetFileName(p), out code, out alt);

            result.Add(new BrowserItem {
                IsFolder = false,
                Name = Path.GetFileName(p),
                Path = p,
                Code = code,
                AltCode = alt,
                LocalImage = FindLocalImage(p, code, imageFiles)
            });
        }

        result.Sort(new NaturalComparer());
        return result;
    }

    string FindLocalImage(string videoPath, string code, List<string> images)
    {
        string videoStem = Path.GetFileNameWithoutExtension(videoPath);

        foreach (string p in images)
        {
            if (String.Equals(
                Path.GetFileNameWithoutExtension(p),
                videoStem,
                StringComparison.OrdinalIgnoreCase
            ))
                return p;
        }

        if (!String.IsNullOrEmpty(code))
        {
            string compact = Regex.Replace(code.ToLowerInvariant(), "[^a-z0-9]", "");

            foreach (string p in images)
            {
                string stem = Path.GetFileNameWithoutExtension(p);

                if (String.Equals(stem, code, StringComparison.OrdinalIgnoreCase))
                    return p;

                string pc = Regex.Replace(stem.ToLowerInvariant(), "[^a-z0-9]", "");
                if (compact.Length > 0 && pc.Contains(compact))
                    return p;
            }
        }

        return null;
    }

    static void ExtractCodeInfo(string fileName, out string displayCode, out string altCode)
    {
        displayCode = "";
        altCode = "";

        string stem = Path.GetFileNameWithoutExtension(fileName);

        stem = Regex.Replace(
            stem,
            @"(?i)\b(?:H26[45]|X26[45]|HEVC|AV1|1080P|2160P|4K|8K|60FPS)\b",
            " "
        );

        MatchCollection matches = CodeRegex.Matches(stem);
        if (matches.Count == 0)
            return;

        Match m = matches[matches.Count - 1];

        string prefix = m.Groups[1].Value.ToUpperInvariant();
        string number = m.Groups[2].Value;
        string suffix = m.Groups[3].Value.ToUpperInvariant();

        displayCode = prefix + "-" + number;
        altCode = suffix.Length > 0 ? displayCode + suffix : "";
    }

    void ApplyFilter()
    {
        string q = searchBox.Text.Trim();

        if (q.Length == 0)
        {
            filteredItems = new List<BrowserItem>(allItems);
        }
        else
        {
            filteredItems = allItems.Where(x =>
                x.Name.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0
                || (!String.IsNullOrEmpty(x.Code)
                    && x.Code.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0)
            ).ToList();
        }

        int folders = filteredItems.Count(x => x.IsFolder);
        int videos = filteredItems.Count(x => !x.IsFolder);
        countLabel.Text = String.Format("폴더 {0} / 동영상 {1}", folders, videos);

        RebuildCards();
    }

    void RebuildCards()
    {
        flow.SuspendLayout();

        foreach (Control c in flow.Controls)
        {
            try
            {
                Panel p = c as Panel;
                if (p != null)
                    DisposeCardImages(p);
            }
            catch {}
        }

        flow.Controls.Clear();
        cardItems.Clear();

        foreach (BrowserItem item in filteredItems)
        {
            Panel card = item.IsFolder ? CreateFolderCard(item) : CreateVideoCard(item);
            flow.Controls.Add(card);
            cardItems[card] = item;
        }

        flow.ResumeLayout();
        ScheduleVisibleThumbCheck();
    }

    Panel BaseCard()
    {
        Panel card = new Panel();
        card.Width = CardWidth;
        card.Height = CardHeight;
        card.Margin = new Padding(6);
        card.BorderStyle = BorderStyle.FixedSingle;
        card.BackColor = SystemColors.ControlLightLight;
        return card;
    }

    Panel CreateFolderCard(BrowserItem item)
    {
        Panel card = BaseCard();

        PictureBox picture = new PictureBox();
        picture.SetBounds(14, 10, CoverWidth, CoverHeight);
        picture.SizeMode = PictureBoxSizeMode.Zoom;
        picture.Image = folderIcon;
        picture.Cursor = Cursors.Hand;
        picture.Tag = "shared";
        picture.Click += delegate { SafeOpenFolderItem(item); };
        card.Controls.Add(picture);

        Label name = new Label();
        name.Text = "📁 " + item.Name;
        name.Font = new Font("Segoe UI", 10.5f, FontStyle.Bold);
        name.TextAlign = ContentAlignment.MiddleCenter;
        name.AutoEllipsis = true;
        name.SetBounds(10, 184, 228, 26);
        card.Controls.Add(name);

        Label kind = new Label();
        kind.Text = "하위 폴더";
        kind.TextAlign = ContentAlignment.MiddleCenter;
        kind.SetBounds(10, 211, 228, 22);
        card.Controls.Add(kind);

        Button open = new Button();
        open.Text = "폴더 열기";
        open.SetBounds(10, 244, 228, 28);
        open.Click += delegate { SafeOpenFolderItem(item); };
        card.Controls.Add(open);

        return card;
    }

    Panel CreateVideoCard(BrowserItem item)
    {
        Panel card = BaseCard();

        PictureBox picture = new PictureBox();
        picture.Name = "cover";
        picture.SetBounds(14, 10, CoverWidth, CoverHeight);
        picture.SizeMode = PictureBoxSizeMode.Zoom;
        picture.BackColor = Color.FromArgb(245,245,245);
        picture.Image = noCoverIcon;
        picture.Tag = "shared";
        picture.Cursor = Cursors.Hand;

        if (!String.IsNullOrEmpty(item.LocalImage) && File.Exists(item.LocalImage))
        {
            TrySetLocalPicture(picture, item.LocalImage);
        }
        else
        {
            byte[] raw = null;
            lock (networkLock)
            {
                remoteBytes.TryGetValue(item.Code ?? "", out raw);
            }

            if (raw != null)
                TrySetBytesPicture(picture, raw);
        }

        picture.Click += delegate { SafeZoomItem(item); };
        card.Controls.Add(picture);

        Label code = new Label();
        code.Text = String.IsNullOrEmpty(item.Code) ? "코드 없음" : item.Code;
        code.Font = new Font("Segoe UI", 10.5f, FontStyle.Bold);
        code.TextAlign = ContentAlignment.MiddleCenter;
        code.SetBounds(10, 182, 228, 25);
        card.Controls.Add(code);

        Label filename = new Label();
        filename.Text = item.Name;
        filename.TextAlign = ContentAlignment.MiddleCenter;
        filename.AutoEllipsis = true;
        filename.SetBounds(10, 207, 228, 22);
        card.Controls.Add(filename);

        Label here = new Label();
        here.Text = "현재 폴더";
        here.TextAlign = ContentAlignment.MiddleCenter;
        here.SetBounds(10, 229, 228, 20);
        card.Controls.Add(here);

        Button play = new Button();
        play.Text = "▶ 재생";
        play.SetBounds(10, 255, 109, 28);
        play.Click += delegate { SafePlayVideo(item); };
        card.Controls.Add(play);

        Button folder = new Button();
        folder.Text = "폴더";
        folder.SetBounds(129, 255, 109, 28);
        folder.Click += delegate { OpenVideoParent(item); };
        card.Controls.Add(folder);

        return card;
    }

    void DisposeCardImages(Panel card)
    {
        foreach (Control c in card.Controls)
        {
            PictureBox pb = c as PictureBox;
            if (pb == null) continue;

            if (pb.Tag != null && String.Equals(pb.Tag.ToString(), "owned"))
            {
                Image old = pb.Image;
                pb.Image = null;
                if (old != null)
                {
                    try { old.Dispose(); } catch {}
                }
            }
        }
    }

    void SafeOpenFolderItem(BrowserItem item)
    {
        if (!Directory.Exists(item.Path))
        {
            statusLabel.Text = "삭제된 폴더 감지 - 목록을 갱신합니다.";
            LoadCurrentDirectory();
            return;
        }

        OpenDirectory(item.Path);
    }

    void SafePlayVideo(BrowserItem item)
    {
        if (!File.Exists(item.Path))
        {
            statusLabel.Text = "삭제된 영상 감지 - 목록을 갱신합니다.";
            LoadCurrentDirectory();

            MessageBox.Show(
                this,
                "이 영상 파일은 외부에서 삭제되었습니다.",
                Text,
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
            return;
        }

        try
        {
            Process.Start(new ProcessStartInfo {
                FileName = item.Path,
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "영상 실행 실패\r\n\r\n" + ex.Message, Text);
        }
    }

    void OpenVideoParent(BrowserItem item)
    {
        string parent = Path.GetDirectoryName(item.Path);

        if (String.IsNullOrEmpty(parent) || !Directory.Exists(parent))
        {
            statusLabel.Text = "부모 폴더가 삭제되었습니다.";
            LoadCurrentDirectory();
            return;
        }

        try
        {
            Process.Start(new ProcessStartInfo {
                FileName = "explorer.exe",
                Arguments = "\"" + parent + "\"",
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "폴더 열기 실패\r\n\r\n" + ex.Message, Text);
        }
    }

    void ScheduleVisibleThumbCheck()
    {
        if (autoThumbCheck == null || !autoThumbCheck.Checked)
            return;

        if (visibleTimer == null)
            return;

        visibleTimer.Stop();
        visibleTimer.Start();
    }

    void QueueVisibleThumbnails()
    {
        if (flow.Controls.Count == 0)
            return;

        Rectangle viewport = flow.ClientRectangle;

        List<int> visibleVideoIndices = new List<int>();

        for (int i = 0; i < flow.Controls.Count; i++)
        {
            Control c = flow.Controls[i];

            BrowserItem item;
            if (!cardItems.TryGetValue(c as Panel, out item) || item.IsFolder)
                continue;

            Rectangle r = c.Bounds;
            if (r.IntersectsWith(viewport))
                visibleVideoIndices.Add(i);
        }

        if (visibleVideoIndices.Count == 0)
            return;

        int start = Math.Max(0, visibleVideoIndices.Min() - BufferItems);
        int end = Math.Min(flow.Controls.Count - 1, visibleVideoIndices.Max() + BufferItems);

        int scheduled = 0;

        for (int i = start; i <= end; i++)
        {
            Panel card = flow.Controls[i] as Panel;
            if (card == null) continue;

            BrowserItem item;
            if (!cardItems.TryGetValue(card, out item))
                continue;

            if (item.IsFolder || String.IsNullOrEmpty(item.Code))
                continue;

            if (!String.IsNullOrEmpty(item.LocalImage) && File.Exists(item.LocalImage))
                continue;

            bool shouldStart = false;

            lock (networkLock)
            {
                if (!remoteBytes.ContainsKey(item.Code)
                    && !failedCodes.Contains(item.Code)
                    && !pendingCodes.Contains(item.Code))
                {
                    pendingCodes.Add(item.Code);
                    shouldStart = true;
                }
            }

            if (!shouldStart)
                continue;

            scheduled++;
            FetchThumbnailAsync(item);
        }

        if (scheduled > 0)
            statusLabel.Text = String.Format("현재 화면 DMM 썸네일 {0}개 확인 중...", scheduled);
    }

    async void FetchThumbnailAsync(BrowserItem item)
    {
        await networkGate.WaitAsync();

        try
        {
            byte[] raw = null;
            string foundUrl = null;

            List<string> candidateCodes = new List<string>();
            candidateCodes.Add(item.Code);

            if (!String.IsNullOrEmpty(item.AltCode)
                && !candidateCodes.Contains(item.AltCode, StringComparer.OrdinalIgnoreCase))
            {
                candidateCodes.Add(item.AltCode);
            }

            string soFallback = item.Code + "SO";
            if (!candidateCodes.Contains(soFallback, StringComparer.OrdinalIgnoreCase))
                candidateCodes.Add(soFallback);

            foreach (string candidateCode in candidateCodes)
            {
                foreach (string url in MakeDmmUrls(candidateCode))
                {
                    try
                    {
                        using (HttpResponseMessage resp = await http.GetAsync(url))
                        {
                            if (!resp.IsSuccessStatusCode)
                                continue;

                            string ct = resp.Content.Headers.ContentType == null
                                ? ""
                                : resp.Content.Headers.ContentType.MediaType;

                            if (String.IsNullOrEmpty(ct)
                                || ct.IndexOf("image", StringComparison.OrdinalIgnoreCase) < 0)
                                continue;

                            byte[] data = await resp.Content.ReadAsByteArrayAsync();

                            if (data == null || data.Length < 5 * 1024)
                                continue;

                            if (data.Length > 20 * 1024 * 1024)
                                continue;

                            if (!CanDecodeImage(data))
                                continue;

                            raw = data;
                            foundUrl = url;
                            break;
                        }
                    }
                    catch
                    {
                        // 다음 URL 계속 검사
                    }
                }

                if (raw != null)
                    break;
            }

            lock (networkLock)
            {
                pendingCodes.Remove(item.Code);

                if (raw != null)
                    remoteBytes[item.Code] = raw;
                else
                    failedCodes.Add(item.Code);
            }

            if (!IsDisposed)
            {
                BeginInvoke((Action)delegate {
                    if (raw != null)
                    {
                        UpdateVisibleCodePictures(item.Code, raw);
                        statusLabel.Text = "DMM 이미지 표시: " + item.Code;
                    }
                });
            }
        }
        finally
        {
            networkGate.Release();
        }
    }

    IEnumerable<string> MakeDmmUrls(string code)
    {
        string key = Regex.Replace(code, "[^A-Za-z0-9]", "").ToLowerInvariant();

        List<string> urls = new List<string>();

        string[] plainPrefixes = new string[] {
            "1", "", "125", "84", "118", "55", "41"
        };

        foreach (string prefix in plainPrefixes)
        {
            string k = prefix + key;
            urls.Add(String.Format(
                "https://pics.dmm.co.jp/mono/movie/adult/{0}/{0}pl.jpg",
                k
            ));
        }

        string[] hPrefixes = new string[] {
            "1100", "84", "084", "118", "55", "055", "125", ""
        };

        foreach (string hp in hPrefixes)
        {
            string b = hp.Length > 0
                ? "h_" + hp + key
                : "h_" + key;

            string kr = b + "r";

            urls.Add(String.Format(
                "https://pics.dmm.co.jp/mono/movie/adult/{0}/{0}pl.jpg",
                kr
            ));

            urls.Add(String.Format(
                "https://pics.dmm.co.jp/mono/movie/adult/{0}/{0}pl.jpg",
                b
            ));
        }

        return urls.Distinct(StringComparer.OrdinalIgnoreCase);
    }

    bool CanDecodeImage(byte[] data)
    {
        try
        {
            using (MemoryStream ms = new MemoryStream(data))
            using (Image img = Image.FromStream(ms, true, true))
            {
                return img.Width > 0 && img.Height > 0;
            }
        }
        catch
        {
            return false;
        }
    }

    void UpdateVisibleCodePictures(string code, byte[] raw)
    {
        foreach (KeyValuePair<Panel, BrowserItem> kv in cardItems)
        {
            BrowserItem item = kv.Value;

            if (item.IsFolder
                || !String.Equals(item.Code, code, StringComparison.OrdinalIgnoreCase))
                continue;

            PictureBox pb = kv.Key.Controls["cover"] as PictureBox;
            if (pb != null)
                TrySetBytesPicture(pb, raw);
        }
    }

    void TrySetBytesPicture(PictureBox pb, byte[] raw)
    {
        try
        {
            using (MemoryStream ms = new MemoryStream(raw))
            using (Image source = Image.FromStream(ms))
            {
                Image clone = new Bitmap(source);

                if (pb.Tag != null && pb.Tag.ToString() == "owned" && pb.Image != null)
                {
                    try { pb.Image.Dispose(); } catch {}
                }

                pb.Image = clone;
                pb.Tag = "owned";
            }
        }
        catch {}
    }

    void TrySetLocalPicture(PictureBox pb, string path)
    {
        try
        {
            using (Image source = Image.FromFile(path))
            {
                Image clone = new Bitmap(source);

                if (pb.Tag != null && pb.Tag.ToString() == "owned" && pb.Image != null)
                {
                    try { pb.Image.Dispose(); } catch {}
                }

                pb.Image = clone;
                pb.Tag = "owned";
            }
        }
        catch
        {
            pb.Image = noCoverIcon;
            pb.Tag = "shared";
        }
    }

    void SafeZoomItem(BrowserItem item)
    {
        if (!File.Exists(item.Path))
        {
            statusLabel.Text = "삭제된 영상 감지 - 목록을 갱신합니다.";
            LoadCurrentDirectory();
            return;
        }

        Image image = null;

        if (!String.IsNullOrEmpty(item.LocalImage) && File.Exists(item.LocalImage))
        {
            try
            {
                using (Image src = Image.FromFile(item.LocalImage))
                    image = new Bitmap(src);
            }
            catch {}
        }

        if (image == null && !String.IsNullOrEmpty(item.Code))
        {
            byte[] raw = null;

            lock (networkLock)
            {
                remoteBytes.TryGetValue(item.Code, out raw);
            }

            if (raw != null)
            {
                try
                {
                    using (MemoryStream ms = new MemoryStream(raw))
                    using (Image src = Image.FromStream(ms))
                        image = new Bitmap(src);
                }
                catch {}
            }
        }

        if (image == null)
            return;

        OpenZoom(image);
    }

    void OpenZoom(Image image)
    {
        CloseZoom();

        zoomOverlay = new Panel();
        zoomOverlay.BackColor = Color.Black;
        zoomOverlay.Dock = DockStyle.Fill;

        zoomPicture = new PictureBox();
        zoomPicture.Dock = DockStyle.Fill;
        zoomPicture.BackColor = Color.Black;
        zoomPicture.SizeMode = PictureBoxSizeMode.Zoom;
        zoomPicture.Cursor = Cursors.Hand;

        zoomImage = image;
        zoomPicture.Image = zoomImage;

        Label hint = new Label();
        hint.Text = "이미지를 다시 클릭하면 돌아갑니다";
        hint.ForeColor = Color.White;
        hint.BackColor = Color.Black;
        hint.TextAlign = ContentAlignment.MiddleCenter;
        hint.Dock = DockStyle.Bottom;
        hint.Height = 28;

        zoomOverlay.Controls.Add(zoomPicture);
        zoomOverlay.Controls.Add(hint);

        Controls.Add(zoomOverlay);
        zoomOverlay.BringToFront();

        zoomPicture.Click += delegate { BeginInvoke((Action)CloseZoom); };

        KeyPreview = true;
        KeyDown += ZoomEscapeHandler;
    }

    void ZoomEscapeHandler(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape && zoomOverlay != null)
        {
            e.Handled = true;
            BeginInvoke((Action)CloseZoom);
        }
    }

    void CloseZoom()
    {
        KeyDown -= ZoomEscapeHandler;

        Panel overlay = zoomOverlay;
        PictureBox picture = zoomPicture;
        Image image = zoomImage;

        zoomOverlay = null;
        zoomPicture = null;
        zoomImage = null;

        if (picture != null)
            picture.Image = null;

        if (overlay != null)
        {
            try
            {
                Controls.Remove(overlay);
                overlay.Dispose();
            }
            catch {}
        }

        if (image != null)
        {
            try { image.Dispose(); } catch {}
        }
    }

    void WatchCurrentFolder()
    {
        if (String.IsNullOrEmpty(currentDir))
            return;

        if (!Directory.Exists(currentDir))
        {
            HandleCurrentFolderDeleted();
            return;
        }

        string now = MakeFolderSnapshot(currentDir);

        if (folderSnapshot != null
            && now != null
            && !String.Equals(now, folderSnapshot, StringComparison.Ordinal)
            && !reloadPending)
        {
            statusLabel.Text = "외부 파일 변경 감지 - 현재 폴더 갱신 중...";
            LoadCurrentDirectory();
            return;
        }

        if (now != null)
            folderSnapshot = now;
    }

    string MakeFolderSnapshot(string folder)
    {
        try
        {
            StringBuilder sb = new StringBuilder();

            foreach (string p in Directory.GetFileSystemEntries(folder)
                .OrderBy(x => Path.GetFileName(x), StringComparer.OrdinalIgnoreCase))
            {
                try
                {
                    bool dir = Directory.Exists(p);
                    FileSystemInfo info = dir
                        ? (FileSystemInfo)new DirectoryInfo(p)
                        : (FileSystemInfo)new FileInfo(p);

                    long size = 0;
                    if (!dir)
                        size = ((FileInfo)info).Length;

                    sb.Append(Path.GetFileName(p));
                    sb.Append('|');
                    sb.Append(dir ? 'D' : 'F');
                    sb.Append('|');
                    sb.Append(size);
                    sb.Append('|');
                    sb.Append(info.LastWriteTimeUtc.Ticks);
                    sb.Append('\n');
                }
                catch {}
            }

            return sb.ToString();
        }
        catch
        {
            return null;
        }
    }

    void HandleCurrentFolderDeleted()
    {
        CloseZoom();

        if (String.IsNullOrEmpty(rootDir) || !Directory.Exists(rootDir))
        {
            currentDir = null;
            allItems.Clear();
            filteredItems.Clear();
            flow.Controls.Clear();
            pathLabel.Text = "선택한 폴더가 삭제되었습니다.";
            statusLabel.Text = "현재 폴더가 삭제되었습니다.";
            return;
        }

        string candidate = currentDir;

        while (!String.IsNullOrEmpty(candidate)
            && !Directory.Exists(candidate)
            && !PathsEqual(candidate, rootDir))
        {
            DirectoryInfo parent = Directory.GetParent(candidate);
            if (parent == null) break;
            candidate = parent.FullName;
        }

        if (String.IsNullOrEmpty(candidate) || !Directory.Exists(candidate))
            candidate = rootDir;

        OpenDirectory(candidate);
    }

    Image MakeFolderIcon()
    {
        Bitmap bmp = new Bitmap(CoverWidth, CoverHeight);

        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Color.FromArgb(245,245,245));

            using (Brush body = new SolidBrush(Color.FromArgb(232,187,59)))
            using (Pen border = new Pen(Color.FromArgb(185,145,38), 2f))
            {
                Rectangle bodyRect = new Rectangle(32, 54, 156, 78);
                g.FillRectangle(body, bodyRect);
                g.DrawRectangle(border, bodyRect);

                Rectangle tab = new Rectangle(47, 38, 64, 31);
                g.FillRectangle(body, tab);
                g.DrawRectangle(border, tab);
            }

            using (Font f = new Font("Segoe UI", 8f))
            using (Brush b = new SolidBrush(Color.DimGray))
            {
                StringFormat sf = new StringFormat();
                sf.Alignment = StringAlignment.Center;
                g.DrawString("FOLDER", f, b, new RectangleF(0, 140, CoverWidth, 20), sf);
            }
        }

        return bmp;
    }

    Image MakeNoCoverIcon()
    {
        Bitmap bmp = new Bitmap(CoverWidth, CoverHeight);

        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Color.FromArgb(235,235,235));

            using (Pen pen = new Pen(Color.FromArgb(145,145,145), 3f))
            {
                g.DrawRectangle(pen, 62, 34, 96, 94);
            }

            Point[] triangle = new Point[] {
                new Point(94,62),
                new Point(94,103),
                new Point(130,82)
            };

            using (Brush b = new SolidBrush(Color.FromArgb(145,145,145)))
                g.FillPolygon(b, triangle);

            using (Font f = new Font("Segoe UI", 8f))
            using (Brush b = new SolidBrush(Color.DimGray))
            {
                StringFormat sf = new StringFormat();
                sf.Alignment = StringAlignment.Center;
                g.DrawString("NO COVER", f, b, new RectangleF(0, 140, CoverWidth, 20), sf);
            }
        }

        return bmp;
    }
}
'@

try {
    Add-Type -TypeDefinition $source -Language CSharp -ReferencedAssemblies @(
        "System.Windows.Forms",
        "System.Drawing",
        "System.Net.Http"
    )

    [System.Windows.Forms.Application]::EnableVisualStyles()
    [System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

    $form = New-Object MainForm
    [System.Windows.Forms.Application]::Run($form)
}
catch {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show(
        "프로그램 시작 중 오류가 발생했습니다.`r`n`r`n$($_.Exception.Message)",
        "JAV Video Manager",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    throw
}
