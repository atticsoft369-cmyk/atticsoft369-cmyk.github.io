﻿JAV Video Manager v1.0 - Windows No-Python Edition
================================================

이 버전은 Python을 사용하지 않습니다.

필요한 것
---------
- Windows 10 / Windows 11
- Windows에 기본 포함된 Windows PowerShell 5.1 및 .NET Framework

별도 설치가 필요 없는 것
-----------------------
- Python
- pip
- requests
- Pillow
- Selenium
- ChromeDriver
- 별도 런타임 설치

실행 방법
---------
JAV_Video_Manager.cmd 를 더블클릭합니다.

구성
----
JAV_Video_Manager.cmd
JAVVideoManager.ps1

두 파일은 같은 폴더에 두십시오.

현재 기능
---------
- 선택한 루트 폴더 기준 폴더 탐색
- 현재 폴더의 하위 폴더를 먼저 이름순으로 표시
- 현재 폴더에 직접 있는 동영상을 그 다음 이름순으로 표시
- [0-good] 같은 앞뒤 장식 문자는 정렬할 때만 무시
- 하위 폴더 클릭 이동 / 상위 폴더 이동
- 동영상 기본 플레이어로 재생
- 영상의 Windows 탐색기 폴더 열기
- 파일명에서 품번 추출
- 숫자 뒤 CH/SO/VR 등이 붙으면 화면 표시 품번에서는 제외
- 파일명 suffix는 DMM 보조 검색 후보로 사용
- 파일명에 SO가 없어도 DMM CDN의 SO 후보 자동 검사
- DMM 이미지 CDN 직접 검사
- 1 / 기본 / 125 / 84 / 118 / 55 / 41 prefix
- h_1100 / h_84 / h_084 / h_118 / h_55 / h_055 / h_125 / h_ 변형
- 이미지는 파일로 저장하지 않고 메모리에만 표시
- 현재 화면 주변 ±10개 항목만 DMM 이미지 요청
- 이미지 전체 비율 표시
- 이미지 클릭 확대 / 다시 클릭 또는 ESC로 닫기
- 약 1.5초마다 현재 폴더의 외부 변경 감지
- 탐색기에서 영상/폴더 삭제·추가·이름 변경 시 자동 갱신
- 삭제된 영상을 재생/확대하려 할 때 프로그램이 종료되지 않도록 방어

중요
----
이 버전은 '단일 EXE'가 아니라 Windows 기본 구성요소만 사용하는
무설치형 버전입니다.

따라서 다른 PC에서도 Windows 10/11이라면 Python 설치 없이
두 파일을 복사하여 JAV_Video_Manager.cmd 만 실행하면 됩니다.

회사 PC에서 PowerShell 실행 자체가 보안 정책으로 차단되어 있는 경우에는
관리자 정책 때문에 실행되지 않을 수 있습니다. 이 경우에는 별도의
Windows EXE 빌드가 필요합니다.


v1.0.1 수정
===========
일부 Windows 환경에서 C# 컴파일 시 아래 두 Timer 클래스가 동시에 참조되어
모호성 오류가 발생하던 문제를 수정했습니다.

- System.Windows.Forms.Timer
- System.Threading.Timer

v1.0.1에서는 UI용 타이머를 명시적으로
System.Windows.Forms.Timer 로 지정합니다.

오류 예:
'Timer'는 'System.Windows.Forms.Timer' 및
'System.Threading.Timer' 사이에 모호한 참조입니다.


v1.0.2 수정
===========
프로그램 생성자 실행 중 아래 오류가 발생하던 문제를 수정했습니다.

오류:
'0개의 인수가 있는 .ctor을(를) 호출하는 동안 예외가 발생했습니다.'
'개체 참조가 개체의 인스턴스로 설정되지 않았습니다.'

원인:
화면을 만드는 도중 FlowLayoutPanel의 Resize 이벤트가 먼저 발생했고,
그 이벤트가 아직 생성되지 않은 visibleTimer를 사용하려 해서
NullReferenceException이 발생했습니다.

수정:
- visibleTimer를 UI 생성 전에 먼저 초기화
- folderWatchTimer도 UI 생성 전에 초기화
- ScheduleVisibleThumbCheck에 null 방어 코드 추가
- UI 생성 완료 후 폴더 감시 Timer 시작


v1.0.3 변경
===========
UI 오른쪽 상단 구석에 작은 `atticsoft` 브랜드 마크를 추가했습니다.

- 기능에는 영향 없음
- 회색의 작은 굵은 글씨
- 창 크기가 변경되어도 오른쪽 상단에 고정


v1.0.4 변경
===========
프로그램 최상단 제목 표시를 변경했습니다.

기존:
JAV Video Manager v1.0.3 - Windows No-Python

변경:
JAV Video Manager v1.0.4 - AtticSoft Presents

영문 표현은 `AtticSoft Present`보다
제작/제공 표기에서 일반적으로 쓰는 `AtticSoft Presents`를 사용했습니다.
